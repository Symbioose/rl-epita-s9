# Adaptateur TextWorld LoRA easy

Base : Qwen/Qwen2.5-0.5B-Instruct, révision 7ae557604adf67be50417f59c2c2f167def9a775.
Données : 355 exemples train, 60 validation.
Graine : 42. LoRA q_proj/v_proj, r=16, alpha=32, dropout=0.05.
Loss uniquement sur les tokens d’action ; historique jusqu’à quatre échanges.

Adapter expérimental étudiant : commandes TextWorld anglaises, sans garantie hors
de cette distribution. Poids de base à télécharger séparément et licence du modèle
Qwen à respecter. La carte de base reste la référence pour ses conditions d’usage.
Les données exactes, empreintes et métriques sont dans cette archive et results/.
Chargement : PeftModel.from_pretrained(base, ce_repertoire).
